package ejercicio;

import lectura.Leer;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int opcion, tam, eleccion, contador = 0, descuento;
		String direccion;
		double precio, dolar = 1.13;
		int metrosCuadrados;
		boolean reformado;
		Pisos listado[], nuevoPiso;
		Inmobiliaria venta;
		
		System.out.println("Bienvenido a la inmobiliaria Pepe.");
		
		System.out.println("¿Cuántos pisos quiere introducir?");
		
		tam = Leer.datoInt();
		
		listado = new Pisos[tam];
		
		venta = new Inmobiliaria (listado);
		
		do {
			System.out.println("Qué desea hacer?");
			System.out.println("0. Salir");
			System.out.println("1. Añadir un nuevo piso.");
			System.out.println("2. Calcular un descuento para un piso de su elección.");
			System.out.println("3. Calcular precio del metro cuadrado de un piso en dolares americanos.");
			System.out.println("4. Calcular ganancia de un piso con un porcentaje de su elección.");
			System.out.println("5. Calcular ganancia al vender todos los pisos con un porcentaje de su elección.");
			System.out.println("6. Consultar datos de los pisos reformados.");
			
			opcion = Leer.datoInt();
			
			switch(opcion) {
				case 0:
					break;
				case 1:
					if(contador+1 > tam) {
						System.out.println("El máximo del array ha sido alcanzado");
					}else {
						System.out.println("Indique la dirección del nuevo piso:");
						direccion = Leer.dato();
						System.out.println("Indique los metros cuadrados de este:");
						metrosCuadrados = Leer.datoInt();
						System.out.println("Indique el precio del piso:");
						precio = Leer.datoDouble();
						System.out.println("Indique si el piso está reformado:");
						System.out.println("1. Para sí.");
						System.out.println("Otro número para no.");
						eleccion = Leer.datoInt();
						
						if(eleccion == 1) {
							reformado = true;
						}else {
							reformado = false;
						}
						nuevoPiso = new Pisos (direccion, metrosCuadrados, reformado, precio);
						venta.nuevoPiso(nuevoPiso, contador);
						contador++;
					}
					break;
				case 2:
					System.out.println("Indique el piso al que quiere aplicar el descuento:");
					eleccion = Leer.datoInt();
					while(eleccion-1 >= contador || eleccion <=0) {
						System.out.println("Ese piso no existe, seleccione de nuevo por favor:");
						eleccion = Leer.datoInt();
					}
					System.out.printf("El precio del piso Nº %d es: %.2f€.\n", eleccion, listado[eleccion-1].getPrecio());
					System.out.println("Indique el descuento que quiere hacerle:");
					descuento = Leer.datoInt();
					venta.imprimirDescuento(eleccion, descuento);
					break;
				case 3:
					System.out.println("Elija el piso:");
					eleccion = Leer.datoInt();
					while(eleccion-1 >= contador || eleccion <=0) {
						System.out.println("Ese piso no existe, seleccione de nuevo por favor:");
						eleccion = Leer.datoInt();
					}
					venta.imprimirMetroDolares(eleccion, dolar);
					break;
				case 4:
					System.out.println("Indique el número del piso a consultar:");
					eleccion = Leer.datoInt();
					while(eleccion-1 >= contador || eleccion <=0) {
						System.out.println("Ese piso no existe, seleccione de nuevo por favor:");
						eleccion = Leer.datoInt();
					}
					System.out.println("Indique el porcentaje que quiere ganarle al piso:");
					descuento = Leer.datoInt();
					venta.imprimirGanancia(eleccion, descuento);
					break;
				case 5:
					System.out.println("¿Qué porcentaje querría incorporar?");
					descuento = Leer.datoInt();
					venta.calcularGananciaTodos(descuento);
					System.out.printf("El dinero total de recaudación sería: %.2f€.\n", Inmobiliaria.recaudacion);
					break;
				case 6:
					venta.imprimirNoReformados(contador);
					break;
				default:
					System.out.println("Error al seleccionar el número, por favor elija de nuevo.");
			}
			
		}while (opcion != 0);
		
		System.out.println("Gracias por usar este programa.");
		
	}

}
