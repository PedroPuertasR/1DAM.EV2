package ejercicio;

import java.util.Arrays;

/**
 * 
 * <pre>
 * 
 * Los métodos que se integran en esta clase son los siguientes:
 * 
 * - Añadir un nuevo piso al array
 * - Calcular el descuento de un piso de nuestra eleccion. Al que también pasamos el porcentaje del descuento.
 * - Caclular el precio del metro cuadrado en dolares americanos, los cuales pasamos en el principal.
 * - Calcular la ganancia de la empresa que vende el piso, al cual pasamos también el porcentaje de ganancia.
 * - Calcular la ganancia total si utilizaramos el mismo porcentaje para todos los pisos.
 * - Imprimir por pantalla los datos de aquellos pisos que no hayan sido reformados.
 * 
 * </pre>
 * 
 * @author Pedro Puertas
 * @see Pisos
 * @see Principal
 */

public class Inmobiliaria {

	//Atributos
	
	private Pisos listado[];
	public static double recaudacion;
	
	//Constructor
	
	public Inmobiliaria(Pisos[] listado) {
		super();
		this.listado = listado;
	}

	//Getters y setters
	
	public Pisos[] getListado() {
		return listado;
	}

	public void setListado(Pisos[] listado) {
		this.listado = listado;
	}

	public static double getRecaudacion() {
		return recaudacion;
	}

	public static void setRecaudacion(double recaudacion) {
		Inmobiliaria.recaudacion = recaudacion;
	}

	//Métodos
	
	@Override
	public String toString() {
		return "Inmobiliaria [listado=" + Arrays.toString(listado) + "]";
	}
	
	public void nuevoPiso(Pisos nuevoPiso, int contador) {
		listado[contador] = nuevoPiso;
	}
	
	/**
	 * Calcular el descuento que queramos aplicarle con un porcentaje a un piso de nuestra elección.
	 * 
	 * @param eleccion
	 * @param descuento
	 * @return devuelve el descuento que le hariamos al piso
	 */
	
	public double calcularDescuento(int eleccion, int descuento) {
		return listado[eleccion-1].getPrecio() * descuento / 100;
	}
	
	public void imprimirDescuento(int eleccion, int descuento) {
		System.out.printf("El precio del piso con el descuento del %d%% es de: %.2f€.\n", descuento, calcularDescuento(eleccion, descuento));
	}
	
	/**
	 * Este método calcular el precio del metro cuadrado en dolares de un piso.
	 * 
	 * @param eleccion
	 * @param dolar
	 * @return devuelve el precio del metro cuadrado en dolares americanos
	 */
	
	public double calcularMetroDolares(int eleccion, double dolar) {
		return listado[eleccion-1].calcularMetroCuadrado() * dolar;
		//El método calcularMetroCuadrado() se encuentra en Pisos y lo que devuelve es el precio / metroCuadrado
	}
	
	public void imprimirMetroDolares(int eleccion, double dolar) {
		System.out.printf("El precio del metro cuadrado del piso Nº%d en dolares es de: %.2f$\n", eleccion, calcularMetroDolares(eleccion, dolar));
	}
	
	/**
	 * Calcula la ganancia de un piso de nuestra elección.
	 * 
	 * @param eleccion
	 * @param porcentaje
	 * @return Este método devuelve la ganancia con un porcentaje que nosotros pasamos de un piso.
	 */
	
	public double calcularGanancia(int eleccion, int porcentaje) {
		return listado[eleccion-1].getPrecio()*porcentaje/100;
	}
	
	public void imprimirGanancia(int eleccion, int porcentaje) {
		System.out.printf("El dinero que ganaría del piso Nº%d sería de: %.2f€.\n", eleccion, calcularGanancia(eleccion, porcentaje));
	}
	
	/**
	 * Se suma la ganancia de todos los pisos en la variable estática recaudacion.
	 * 
	 * @param porcentaje
	 */
	
	public void calcularGananciaTodos(int porcentaje) {
		recaudacion = 0;
		for (int i = 0; i < listado.length; i++) {
			recaudacion+= calcularGanancia(i+1, porcentaje);
		}
	}
	
	/**
	 * Imprimir por pantalla los datos de aquellos pisos que no hayan sido reformados.
	 * 
	 * @param contador
	 */
	
	public void imprimirNoReformados(int contador) {
		for (int i = 0; i <contador; i++) {
			if(listado[i].isReformado()) {
				System.out.printf("Nº%d:\t\tDirección:%s.\n\t\tMetros Cuadrados: %d.\n\t\tReformado: Sí.\n\t\tPrecio: %.2f€.\n\n"
						, (i+1), listado[i].getDireccion(), listado[i].getMetrosCuadrados(), listado[i].getPrecio());
			}
		}
	}
	
}
