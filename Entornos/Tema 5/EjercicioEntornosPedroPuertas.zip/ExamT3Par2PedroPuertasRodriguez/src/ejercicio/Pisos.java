package ejercicio;

public class Pisos {

	//Atributos
	
	private String direccion;
	private int metrosCuadrados;
	private boolean reformado;
	private double precio;
	
	//Constructor
	
	public Pisos(String direccion, int metrosCuadrados, boolean reformado, double precio) {
		super();
		this.direccion = direccion;
		this.metrosCuadrados = metrosCuadrados;
		this.reformado = reformado;
		this.precio = precio;
	}

	//Getters y setters
	
	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getMetrosCuadrados() {
		return metrosCuadrados;
	}

	public void setMetrosCuadrados(int metrosCuadrados) {
		this.metrosCuadrados = metrosCuadrados;
	}

	public boolean isReformado() {
		return reformado;
	}

	public void setReformado(boolean reformado) {
		this.reformado = reformado;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	//Métodos
	
	@Override
	public String toString() {
		return "Pisos [direccion=" + direccion + ", metrosCuadrados=" + metrosCuadrados + ", reformado=" + reformado
				+ ", precio=" + precio + "]";
	}
	
	public double calcularMetroCuadrado() {
		return precio/metrosCuadrados;
	}
	
}
